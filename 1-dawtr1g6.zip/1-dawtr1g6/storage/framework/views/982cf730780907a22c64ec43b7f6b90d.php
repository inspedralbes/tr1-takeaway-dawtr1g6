<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Ver Catálogo Admin</title>
</head>

<body>

    <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="producto">
            <img src="<?php echo e($producto->image_url); ?>" alt="Product Image">
            <h3>Nom: <?php echo e($producto->name); ?></h3>
            <h3>Stock: <?php echo e($producto->stock); ?></h3>
            <h3>Precio: $<?php echo e($producto->price); ?></h3>
            <a href ="<?php echo e(url('showProducto-item/' . $producto->id)); ?> ">Ver detalles</a>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <style>
        body {
            background-color: whitesmoke;
        }

        .producto {
            background-color: #F27405;
            ;
            border: 2px solid black;
            border-radius: 8px;
            padding: 16px;
            font-size: 20px;
            margin: 16px;
            width: 300px;
            text-align: center;
            color: white;
        }

        .producto img {
            max-width: 100%;
            border-radius: 8px;
            margin-bottom: 10px;
        }

        .producto h3 {
            font-size: 1.2em;
            margin-bottom: 8px;
        }

        .producto p {
            font-size: 1em;
            margin-bottom: 6px;
        }
        a{
            text-decoration: none;
        }

        .producto strong {
            font-weight: bold;
            margin-right: 4px;
        }

        /* Estilos adicionales según tus preferencias */
    </style>

</body>

</html>
<?php /**PATH C:\Users\a22joslarfer\Desktop\dawtr1g6\tr1-takeaway-dawtr1g6\1-dawtr1g6\resources\views/botiga/showProductosAdmin.blade.php ENDPATH**/ ?>