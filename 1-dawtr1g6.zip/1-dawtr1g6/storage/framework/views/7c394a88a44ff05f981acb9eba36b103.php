<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Ver Catálogo Admin</title>
</head>

<body>

    <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <img src="<?php echo e($producto->image_url); ?>" class="card-img-top" alt="Product Image">
        <h3>Nom: <?php echo e($producto->name); ?></h3>
        <h3>Stock: <?php echo e($producto->stock); ?></h3>
        <h3>Precio: $<?php echo e($producto->price); ?></h3>
        <a class="btn btn-primary" href ="<?php echo e(url('showProducto-item/' . $producto->id)); ?> ">Ver detalles</a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>

</html>
<?php /**PATH C:\Users\a22joslarfer\1-dawtr1g6\resources\views/botiga/showProductosAdmin.blade.php ENDPATH**/ ?>