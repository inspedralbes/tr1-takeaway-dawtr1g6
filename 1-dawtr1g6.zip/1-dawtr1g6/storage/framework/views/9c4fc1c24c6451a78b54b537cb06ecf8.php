<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>AAAAAA</title>
</head>

<body>

 
        <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
            <p>Nombre: <?php echo e($producto->nom); ?></p>
            <p>Stock: <?php echo e($producto->stock); ?></p>
            <p>Precio: <?php echo e($producto->price); ?></p>
            <p>Imagen: <?php echo e($producto->imatge); ?></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   
</body>

</html>
<?php /**PATH C:\Users\a22joslarfer\1-dawtr1g6\resources\views/botiga/getProductos.blade.php ENDPATH**/ ?>