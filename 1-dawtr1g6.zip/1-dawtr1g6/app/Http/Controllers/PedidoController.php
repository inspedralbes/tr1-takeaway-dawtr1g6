<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Pedido;
use App\Models\Producto;



class PedidoController extends Controller
{
    //

    public function getPedidos(Request $request)
    {
        $jsonData = $request->json()->all();

        foreach ($jsonData['pedidos'] as $item) {
            $pedidos = new Pedido();
            $pedidos->status = $item['status'];
            $pedidos->sumatori = $item['sumatori'];
            $pedidos->save();
        }

        $response = [
            'success' => true,
            'message' => 'Pedidos guardados correctamente.'
        ];

        return ($response);


    }
    public function showPedidos()
    {
        $pedidos = Pedido::all();
        return view('botiga.showPedidos', compact('pedidos'));
    }


    public function giveJsonPedidosData()
    {
        $pedidos = Pedido::all();
        return json_encode($pedidos, JSON_PRETTY_PRINT);    

    }



    public function showPedido_item(Request $request)
    {

        // $request deberia de ser la id del usuario ...
        $pedidos = Pedido::find($request->id);

        return view('botiga.showPedido-item', compact('pedidos'));

    }

  











    public function showPedidosAdmin()
    {
        $pedidos = Pedido::all();
        return view('botiga.showPedidosAdmin', compact('pedidos'));
    }

}
