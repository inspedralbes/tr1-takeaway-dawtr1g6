<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Pedido;
use App\Models\Producto;
use Illuminate\Http\Request;

class ProductoController extends Controller
{
    // PILLA DE UN JSON SU DATA Y CORRECTAMENTE LA INTRODUCE A LA BD
    public function getProductos(Request $request)
    {
        $jsonData = $request->json()->all();

        foreach ($jsonData['productos'] as $item) {
            $producto = new Producto();
            $producto->name = $item['name'];
            $producto->stock = $item['stock'];
            $producto->price = $item['price'];
            $producto->image_url = $item['image_url'];
            $producto->save();
        }

        $response = [
            'success' => true,
            'message' => 'Productos guardados correctamente.'
        ];

        return ($response);


    }


    // MUESTRA CORRECTAMENTE LOS PRODUCTOS DE LA BD 
    public function showProductos()
    {
        $productos = Producto::all();

        return view('botiga.showProductos', compact('productos'));
    }


    public function showProducto_item(Request $request)
    {

        $productos = Producto::find($request->id);

        return view('botiga.showProducto-item', compact('productos'));
    }


    public function showProductosAdmin()
    {
        $productos = Producto::all();

        return view('botiga.showProductosAdmin', compact('productos'));
    }


    public function giveJsonProductosData()
    {
        $productos = Producto::all();
        return json_encode($productos, JSON_PRETTY_PRINT);    

    }


    public function realizarPedido(Request $request)
    {

        $jsonData = $request->json()->all();

        $pedido = new Pedido();
        $pedido->user_id = $jsonData['user_id'];
        $pedido->pedido_id = $jsonData['producto_id'];

        $pedido->save();

    }
}
