<?php

use App\Http\Controllers\PedidoController;
use App\Http\Controllers\ProductoController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/showPedidosAdmin', [PedidoController::class, 'showPedidosAdmin']);
Route::get('/showProductosAdmin', [ProductoController::class, 'showProductosAdmin']);


Route::post('/getJsonProductos', [ProductoController::class, 'giveJsonProductosData']);
Route::post('/getJsonPedidos', [PedidoController::class, 'giveJsonPedidosData']);

//Route::get("/showMisPedidos", [PedidoController::class, "showMisPedidos"]);
//Route::get("/showProducto-item", [ProductoController::class, "showProducto_item"]);





